import React, { useState } from 'react';
import { useToast } from '@/hooks/use-toast';

const Footer = () => {
  const { toast } = useToast();
  const [newsletterEmail, setNewsletterEmail] = useState('');

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.includes('@')) {
      toast({
        title: "Email inválido",
        description: "Por favor, insira um email válido.",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Inscrição realizada!",
      description: "Obrigado por se inscrever em nossa newsletter!",
    });
    setNewsletterEmail('');
  };

  const services = [
    "SEO & Marketing de Busca",
    "Gestão de Mídia Paga",
    "Gestão de Redes Sociais",
    "Email Marketing",
    "Web Design & Desenvolvimento",
    "Análise de Dados & Relatórios"
  ];

  const quickLinks = [
    "Sobre Nós",
    "Portfólio",
    "Depoimentos",
    "Blog",
    "Carreiras",
    "Contato"
  ];

  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <a href="/" className="block mb-6">
              <img 
                src="https://static.readdy.ai/image/dacb83b8c4b27c8310a9a241c9337d0f/c139f65433ba698ba0dc9a4ca8f81afc.png" 
                alt="AgênciaMAX" 
                className="h-24"
              />
            </a>
            <p className="text-gray-400 mb-6">
              Transformando negócios através de estratégias digitais inovadoras e resultados mensuráveis.
            </p>
            <p className="text-gray-400 mb-2">
              <strong>Endereço:</strong> Av. Cesar Romero, 1553, Feira de Santana - BA
            </p>
            <p className="text-gray-400 mb-2">
              <strong>Email:</strong> agenciamaxbrasil@gmail.com
            </p>
            <p className="text-gray-400 mb-6">
              <strong>Telefone:</strong> (75) 98857-6357
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition duration-300">
                <i className="ri-facebook-fill ri-lg"></i>
              </a>
              <a href="https://www.instagram.com/agenciamaxbr/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition duration-300">
                <i className="ri-instagram-fill ri-lg"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition duration-300">
                <i className="ri-linkedin-fill ri-lg"></i>
              </a>
              <a href="https://x.com/AgenciaMAX_BR" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition duration-300">
                <i className="ri-twitter-x-fill ri-lg"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-6">Serviços</h4>
            <ul className="space-y-3">
              {services.map((service, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-400 hover:text-white transition duration-300">
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-6">Links Rápidos</h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-400 hover:text-white transition duration-300">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-6">Newsletter</h4>
            <p className="text-gray-400 mb-4">
              Inscreva-se para receber dicas, novidades e conteúdos exclusivos sobre marketing digital.
            </p>
            <form onSubmit={handleNewsletterSubmit} className="mb-4">
              <div className="flex">
                <input 
                  type="email" 
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder="Seu email" 
                  className="px-4 py-3 rounded-l-button border-none flex-grow text-gray-800 focus:outline-none"
                  required
                />
                <button 
                  type="submit" 
                  className="bg-primary text-white px-4 py-3 rounded-r-button hover:bg-opacity-90 transition duration-300 whitespace-nowrap"
                >
                  Inscrever
                </button>
              </div>
            </form>
            <p className="text-gray-400 text-sm">
              Ao se inscrever, você concorda com nossa <a href="#" className="text-primary hover:underline">Política de Privacidade</a>.
            </p>
          </div>
        </div>
        
        <div className="pt-8 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 mb-4 md:mb-0">
            &copy; 2025 AgênciaMAX. Todos os direitos reservados.
          </p>
          <div className="flex space-x-6">
            <a href="#" className="text-gray-400 hover:text-white transition duration-300">Termos de Uso</a>
            <a href="#" className="text-gray-400 hover:text-white transition duration-300">Política de Privacidade</a>
            <a href="#" className="text-gray-400 hover:text-white transition duration-300">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
