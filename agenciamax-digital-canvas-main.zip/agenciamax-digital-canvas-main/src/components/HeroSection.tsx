
import React from 'react';

const HeroSection = () => {
  return (
    <section className="hero-bg min-h-screen flex items-center pt-20 pb-16">
      <div className="container mx-auto px-4 w-full">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0 bg-white bg-opacity-90 p-8 md:p-12 rounded-lg shadow-xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
              Transforme sua <span className="text-primary">presença digital</span> com estratégias que geram resultados
            </h1>
            <p className="text-lg text-gray-700 mb-8">
              A AgênciaMAX desenvolve soluções personalizadas de marketing digital para impulsionar seu negócio no ambiente online, aumentando sua visibilidade e convertendo visitantes em clientes.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a href="#contato" className="bg-primary text-white px-8 py-4 rounded-button font-semibold text-center hover:bg-opacity-90 transition duration-300 whitespace-nowrap">
                Solicitar Proposta
              </a>
              <a href="#servicos" className="border-2 border-primary text-primary px-8 py-4 rounded-button font-semibold text-center hover:bg-primary hover:text-white transition duration-300 whitespace-nowrap">
                Nossos Serviços
              </a>
            </div>
          </div>
          <div className="md:w-1/2 md:pl-10">
            {/* Decorative element */}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
