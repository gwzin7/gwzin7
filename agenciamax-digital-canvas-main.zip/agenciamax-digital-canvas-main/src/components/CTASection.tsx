

import React from 'react';

const CTASection = () => {
  return (
    <section className="py-20 bg-primary bg-opacity-5 paper-texture">
      <div className="container mx-auto px-4">
        <div className="bg-white p-10 rounded-lg shadow-xl border border-primary border-opacity-20 max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Pronto para impulsionar seu negócio?
            </h2>
            <p className="text-lg text-gray-700">
              Agende uma consultoria gratuita e descubra como podemos ajudar sua empresa a crescer no ambiente digital.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="#contato" className="bg-primary text-white px-8 py-4 rounded-button font-semibold text-center hover:bg-opacity-90 transition duration-300 whitespace-nowrap">
              Agendar Consultoria
            </a>
            <a href="https://wa.me/qr/HBQHBXUI4OFKA1" target="_blank" rel="noopener noreferrer" className="border-2 border-primary text-primary px-8 py-4 rounded-button font-semibold text-center hover:bg-primary hover:text-white transition duration-300 flex items-center justify-center whitespace-nowrap">
              <i className="ri-phone-line ri-lg mr-2"></i> (75) 98857-6357
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;

