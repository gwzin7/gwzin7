
import React from 'react';

const PortfolioSection = () => {
  const portfolioItems = [
    {
      image: "https://readdy.ai/api/search-image?query=modern%20e-commerce%20website%20design%20with%20red%20accents%2C%20minimalist%20user%20interface%2C%20product%20showcase%20page%20with%20clean%20layout%2C%20professional%20web%20design%2C%20digital%20marketing%20project%20example%2C%20high-end%20website%20design&width=600&height=400&seq=portfolio1&orientation=landscape",
      title: "E-commerce Moda Sustentável",
      description: "Desenvolvimento de plataforma de e-commerce e estratégia de marketing digital para marca de moda sustentável.",
      tags: ["E-commerce", "SEO", "Mídia Paga"]
    },
    {
      image: "https://readdy.ai/api/search-image?query=social%20media%20marketing%20campaign%20with%20red%20brand%20identity%2C%20instagram%20and%20facebook%20posts%20layout%2C%20digital%20marketing%20strategy%20visualization%2C%20content%20calendar%2C%20professional%20social%20media%20management%20example&width=600&height=400&seq=portfolio2&orientation=landscape",
      title: "Campanha Redes Sociais",
      description: "Estratégia de conteúdo e gestão de redes sociais para rede de restaurantes, com aumento de 150% no engajamento.",
      tags: ["Redes Sociais", "Conteúdo", "Engajamento"]
    },
    {
      image: "https://readdy.ai/api/search-image?query=google%20ads%20campaign%20dashboard%20with%20performance%20metrics%2C%20digital%20marketing%20analytics%2C%20search%20engine%20marketing%20results%2C%20professional%20PPC%20campaign%20management%2C%20red%20accent%20color%20theme%2C%20data%20visualization&width=600&height=400&seq=portfolio3&orientation=landscape",
      title: "Campanha Google Ads",
      description: "Gestão de campanhas de Google Ads para empresa de tecnologia, com redução de 40% no custo por aquisição.",
      tags: ["Google Ads", "SEM", "Conversão"]
    }
  ];

  return (
    <section id="portfolio" className="py-20 paper-texture">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Nosso Portfólio</h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Conheça alguns dos projetos que desenvolvemos e os resultados que alcançamos para nossos clientes.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {portfolioItems.map((item, index) => (
            <div key={index} className="bg-white rounded-lg overflow-hidden shadow-lg">
              <img 
                src={item.image}
                alt={item.title}
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-700 mb-4">{item.description}</p>
                <div className="flex flex-wrap gap-2">
                  {item.tags.map((tag, tagIndex) => (
                    <span key={tagIndex} className="bg-gray-100 text-gray-800 text-sm px-3 py-1 rounded-full">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <a href="#contato" className="bg-primary text-white px-8 py-3 rounded-button font-medium hover:bg-opacity-90 transition duration-300 inline-block whitespace-nowrap">
            Ver Mais Projetos
          </a>
        </div>
      </div>
    </section>
  );
};

export default PortfolioSection;
