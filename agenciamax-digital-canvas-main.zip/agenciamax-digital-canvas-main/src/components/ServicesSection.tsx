
import React from 'react';

const ServicesSection = () => {
  const services = [
    {
      icon: "ri-search-line",
      title: "SEO & Marketing de Busca",
      description: "Otimizamos seu site para os motores de busca, aumentando sua visibilidade orgânica e garantindo que sua marca seja encontrada pelo público certo."
    },
    {
      icon: "ri-advertisement-line",
      title: "Gestão de Mídia Paga",
      description: "Criamos e gerenciamos campanhas de anúncios altamente segmentadas no Google, Facebook, Instagram e outras plataformas para maximizar seu ROI."
    },
    {
      icon: "ri-instagram-line",
      title: "Gestão de Redes Sociais",
      description: "Desenvolvemos estratégias de conteúdo e engajamento para suas redes sociais, construindo uma comunidade ativa e fortalecendo sua presença digital."
    },
    {
      icon: "ri-mail-line",
      title: "Email Marketing",
      description: "Criamos campanhas de email marketing personalizadas que nutrem leads, convertem clientes e fortalecem o relacionamento com sua audiência."
    },
    {
      icon: "ri-layout-line",
      title: "Web Design & Desenvolvimento",
      description: "Desenvolvemos sites responsivos, landing pages e e-commerces otimizados para conversão, com design moderno e experiência de usuário excepcional."
    },
    {
      icon: "ri-bar-chart-line",
      title: "Análise de Dados & Relatórios",
      description: "Monitoramos e analisamos o desempenho das suas campanhas, fornecendo insights valiosos para otimizar suas estratégias e maximizar resultados."
    }
  ];

  return (
    <section id="servicos" className="py-20 paper-texture">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Nossos Serviços</h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Oferecemos soluções completas de marketing digital para impulsionar sua marca no ambiente online.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="service-card bg-white p-8 rounded-lg shadow-lg transition duration-300 border-t-4 border-primary">
              <div className="w-16 h-16 flex items-center justify-center bg-primary bg-opacity-10 rounded-full mb-6">
                <i className={`${service.icon} ri-xl text-primary`}></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">{service.title}</h3>
              <p className="text-gray-700 mb-6">{service.description}</p>
              <a href="#contato" className="text-primary font-medium flex items-center hover:underline">
                Saiba mais <i className="ri-arrow-right-line ri-sm ml-2"></i>
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
