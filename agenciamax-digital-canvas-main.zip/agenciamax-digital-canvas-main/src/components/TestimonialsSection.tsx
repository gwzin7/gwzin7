
import React from 'react';

const TestimonialsSection = () => {
  const testimonials = [
    {
      text: "A AgênciaMAX transformou completamente nossa presença digital. Em apenas 3 meses, aumentamos nossas vendas online em 70% e expandimos nossa base de clientes. A equipe é extremamente profissional e atenciosa.",
      name: "Renata Oliveira",
      role: "Diretora de Marketing, Moda Sustentável"
    },
    {
      text: "As campanhas de Google Ads desenvolvidas pela AgênciaMAX superaram todas as nossas expectativas. Conseguimos reduzir o custo por lead em 40% e aumentar a taxa de conversão em 25%. Recomendo sem hesitar!",
      name: "Carlos Mendes",
      role: "CEO, TechSolutions"
    },
    {
      text: "A estratégia de conteúdo desenvolvida pela AgênciaMAX para nossas redes sociais foi um divisor de águas. Nosso engajamento aumentou significativamente e conseguimos construir uma comunidade fiel ao redor da nossa marca.",
      name: "Fernanda Costa",
      role: "Proprietária, Rede Sabor Gourmet"
    }
  ];

  return (
    <section id="depoimentos" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">O Que Nossos Clientes Dizem</h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Conheça a experiência de quem já transformou seu negócio com nossas soluções de marketing digital.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white p-8 rounded-lg shadow-lg">
              <div className="flex items-center mb-6">
                <div className="text-primary">
                  {[...Array(5)].map((_, i) => (
                    <i key={i} className="ri-star-fill ri-lg"></i>
                  ))}
                </div>
              </div>
              <p className="text-gray-700 mb-6 italic">"{testimonial.text}"</p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-user-line ri-lg text-gray-500"></i>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                  <p className="text-gray-600">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
