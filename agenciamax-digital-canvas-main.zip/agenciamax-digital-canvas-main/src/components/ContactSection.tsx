import React, { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import emailjs from '@emailjs/browser';
const ContactSection = () => {
  const {
    toast
  } = useToast();
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    telefone: '',
    nome_empresa: '',
    servicos_interesse: '',
    mensagem: '',
    privacy: false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Initialize EmailJS
  React.useEffect(() => {
    emailjs.init("nFx6ssoh064cutaUF");
  }, []);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const {
      name,
      value,
      type
    } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (!formData.nome.trim() || !formData.email.trim() || !formData.privacy) {
      toast({
        title: "Erro no formulário",
        description: "Por favor, preencha os campos obrigatórios e aceite a política de privacidade.",
        variant: "destructive"
      });
      return;
    }
    if (!formData.email.includes('@')) {
      toast({
        title: "Email inválido",
        description: "Por favor, insira um email válido.",
        variant: "destructive"
      });
      return;
    }
    setIsSubmitting(true);
    try {
      const templateParams = {
        nome: formData.nome,
        nome_empresa: formData.nome_empresa,
        telefone: formData.telefone,
        email: formData.email,
        servicos_interesse: formData.servicos_interesse,
        mensagem: formData.mensagem
      };
      await emailjs.send('service_z1oma6g', 'template_yq4ey6j', templateParams);
      toast({
        title: "Mensagem enviada!",
        description: "E-mail enviado com sucesso! Obrigado pelo contato."
      });
      setFormData({
        nome: '',
        email: '',
        telefone: '',
        nome_empresa: '',
        servicos_interesse: '',
        mensagem: '',
        privacy: false
      });
    } catch (error) {
      console.error('EmailJS error:', error);
      toast({
        title: "Erro no envio",
        description: "Erro ao enviar o e-mail, tente novamente.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const contactInfo = [{
    icon: "ri-map-pin-line",
    title: "Endereço",
    content: "Av. Cesar Romero, 1553, Feira de Santana - BA"
  }, {
    icon: "ri-mail-line",
    title: "Email",
    content: "agenciamaxbrasil@gmail.com"
  }, {
    icon: "ri-phone-line",
    title: "Telefone",
    content: "(75) 98857-6357"
  }];
  return <section id="contato" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row">
          <div className="lg:w-1/2 mb-10 lg:mb-0 lg:pr-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Entre em Contato</h2>
            <p className="text-lg text-gray-700 mb-8">
              Estamos prontos para ajudar sua empresa a alcançar todo o seu potencial no ambiente digital. Preencha o formulário ao lado ou utilize um dos canais abaixo para entrar em contato conosco.
            </p>
            
            <div className="space-y-6 mb-10">
              {contactInfo.map((info, index) => <div key={index} className="flex items-start">
                  <div className="w-10 h-10 flex items-center justify-center bg-primary bg-opacity-10 rounded-full mr-4">
                    <i className={`${info.icon} ri-lg text-primary`}></i>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">{info.title}</h4>
                    <p className="text-gray-700">{info.content}</p>
                  </div>
                </div>)}
            </div>
            
            <div>
              <h4 className="font-bold text-gray-900 mb-4">Siga-nos nas redes sociais</h4>
              <div className="flex space-x-4">
                
                <a href="https://www.instagram.com/agenciamaxbr/" target="_blank" rel="noopener noreferrer" className="w-10 h-10 flex items-center justify-center bg-primary text-white rounded-full hover:bg-opacity-90 transition duration-300">
                  <i className="ri-instagram-fill ri-lg"></i>
                </a>
                
                <a href="https://x.com/AgenciaMAX_BR" target="_blank" rel="noopener noreferrer" className="w-10 h-10 flex items-center justify-center bg-primary text-white rounded-full hover:bg-opacity-90 transition duration-300">
                  <i className="ri-twitter-x-fill ri-lg"></i>
                </a>
              </div>
            </div>
          </div>
          
          <div className="lg:w-1/2">
            <form onSubmit={handleSubmit} className="bg-white p-8 rounded-lg shadow-lg">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="nome" className="block text-gray-700 font-medium mb-2">Nome *</label>
                  <input type="text" id="nome" name="nome" value={formData.nome} onChange={handleInputChange} className="w-full px-4 py-3 border border-gray-300 rounded focus:border-primary focus:outline-none" placeholder="Seu nome" required />
                </div>
                <div>
                  <label htmlFor="email" className="block text-gray-700 font-medium mb-2">Email *</label>
                  <input type="email" id="email" name="email" value={formData.email} onChange={handleInputChange} className="w-full px-4 py-3 border border-gray-300 rounded focus:border-primary focus:outline-none" placeholder="seu@email.com" required />
                </div>
              </div>
              
              <div className="mb-6">
                <label htmlFor="telefone" className="block text-gray-700 font-medium mb-2">Telefone *</label>
                <input type="tel" id="telefone" name="telefone" value={formData.telefone} onChange={handleInputChange} className="w-full px-4 py-3 border border-gray-300 rounded focus:border-primary focus:outline-none" placeholder="Telefone de contato" pattern="[\d\s()+-]{8,}" title="Telefone válido, por favor" required />
              </div>
              
              <div className="mb-6">
                <label htmlFor="nome_empresa" className="block text-gray-700 font-medium mb-2">Nome da Empresa *</label>
                <input type="text" id="nome_empresa" name="nome_empresa" value={formData.nome_empresa} onChange={handleInputChange} className="w-full px-4 py-3 border border-gray-300 rounded focus:border-primary focus:outline-none" placeholder="Nome da empresa" required />
              </div>
              
              <div className="mb-6">
                <label htmlFor="servicos_interesse" className="block text-gray-700 font-medium mb-2">Serviços de Interesse *</label>
                <input type="text" id="servicos_interesse" name="servicos_interesse" value={formData.servicos_interesse} onChange={handleInputChange} className="w-full px-4 py-3 border border-gray-300 rounded focus:border-primary focus:outline-none" placeholder="Serviços de interesse" required />
              </div>
              
              <div className="mb-6">
                <label htmlFor="mensagem" className="block text-gray-700 font-medium mb-2">Mensagem *</label>
                <textarea id="mensagem" name="mensagem" value={formData.mensagem} onChange={handleInputChange} rows={4} className="w-full px-4 py-3 border border-gray-300 rounded focus:border-primary focus:outline-none" placeholder="Sua mensagem" required></textarea>
              </div>
              
              <div className="mb-6 flex items-start">
                <input type="checkbox" id="privacy" name="privacy" checked={formData.privacy} onChange={handleInputChange} className="custom-checkbox mr-3" required />
                <label htmlFor="privacy" className="text-gray-700">
                  Concordo com a <a href="#" className="text-primary hover:underline">Política de Privacidade</a> e autorizo o contato da AgênciaMAX. *
                </label>
              </div>
              
              <button type="submit" disabled={isSubmitting} className="w-full bg-primary text-white py-4 rounded-button font-semibold hover:bg-opacity-90 transition duration-300 whitespace-nowrap disabled:opacity-50">
                {isSubmitting ? 'Enviando... ⏳' : 'Enviar Mensagem'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>;
};
export default ContactSection;
