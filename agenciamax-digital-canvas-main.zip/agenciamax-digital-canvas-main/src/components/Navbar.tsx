
import React, { useState } from 'react';

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="fixed w-full bg-white bg-opacity-95 shadow-sm z-50">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <a href="/" className="flex items-center">
          <img 
            src="https://static.readdy.ai/image/dacb83b8c4b27c8310a9a241c9337d0f/c139f65433ba698ba0dc9a4ca8f81afc.png" 
            alt="AgênciaMAX" 
            className="h-20"
          />
        </a>
        
        <div className="hidden md:flex space-x-8 items-center">
          <a href="#servicos" className="text-gray-800 hover:text-primary font-medium transition duration-300">
            Serviços
          </a>
          <a href="#sobre" className="text-gray-800 hover:text-primary font-medium transition duration-300">
            Sobre
          </a>
          <a href="#portfolio" className="text-gray-800 hover:text-primary font-medium transition duration-300">
            Portfólio
          </a>
          <a href="#depoimentos" className="text-gray-800 hover:text-primary font-medium transition duration-300">
            Depoimentos
          </a>
          <a href="#contato" className="bg-primary text-white px-6 py-2 rounded-button font-medium hover:bg-opacity-90 transition duration-300 whitespace-nowrap">
            Fale Conosco
          </a>
        </div>
        
        <div className="md:hidden w-10 h-10 flex items-center justify-center">
          <button onClick={toggleMobileMenu} className="text-gray-800">
            <i className={`${isMobileMenuOpen ? 'ri-close-line' : 'ri-menu-line'} ri-lg`}></i>
          </button>
        </div>
      </div>
      
      {/* Mobile menu */}
      <div className={`${isMobileMenuOpen ? 'block' : 'hidden'} md:hidden bg-white w-full border-t border-gray-100`}>
        <div className="container mx-auto px-4 py-3 flex flex-col space-y-3">
          <a href="#servicos" onClick={closeMobileMenu} className="text-gray-800 py-2 hover:text-primary font-medium">
            Serviços
          </a>
          <a href="#sobre" onClick={closeMobileMenu} className="text-gray-800 py-2 hover:text-primary font-medium">
            Sobre
          </a>
          <a href="#portfolio" onClick={closeMobileMenu} className="text-gray-800 py-2 hover:text-primary font-medium">
            Portfólio
          </a>
          <a href="#depoimentos" onClick={closeMobileMenu} className="text-gray-800 py-2 hover:text-primary font-medium">
            Depoimentos
          </a>
          <a href="#contato" onClick={closeMobileMenu} className="bg-primary text-white px-6 py-2 rounded-button font-medium hover:bg-opacity-90 transition duration-300 text-center whitespace-nowrap">
            Fale Conosco
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
